import React, { useState } from "react";

const HOMOGLYPH_MAP = {
  A: ["Α", "А", "Ꭺ"],
  B: ["Β", "В"],
  C: ["Ϲ", "С"],
  E: ["Ε", "Е"],
  H: ["Η", "Н"],
  I: ["Ι", "І", "Ӏ"],
  K: ["Κ", "К"],
  M: ["Μ", "М"],
  O: ["Ο", "О", "Օ"],
  P: ["Ρ", "Р"],
  S: ["Ѕ"],
  T: ["Τ", "Т"],
  X: ["Χ", "Х"],
  Y: ["Υ", "Ү"],
  a: ["а", "α"],
  c: ["ϲ", "с"],
  e: ["е", "ε"],
  i: ["і", "ι", "ӏ"],
  o: ["ο", "о", "օ"],
  p: ["р"],
  s: ["ѕ"],
  x: ["х", "χ"],
  " ": ["\u00A0"]
};

const REV = Object.fromEntries(
  Object.entries(HOMOGLYPH_MAP).flatMap(([base, arr]) => arr.map((c) => [c, base]))
);

export default function HomoglyphDetector() {
  const [text, setText] = useState("");
  const [found, setFound] = useState([]);
  const [normalized, setNormalized] = useState("");

  const analyze = (input) => {
    const hits = [];
    const out = [];
    for (let i = 0; i < input.length; i++) {
      const ch = input[i];
      if (REV[ch]) {
        hits.push({ index: i, char: ch, base: REV[ch] });
        out.push(REV[ch]);
      } else out.push(ch);
    }
    setFound(hits);
    setNormalized(out.join(""));
  };

  const handleFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const c = String(e.target.result || "");
      setText(c);
      analyze(c);
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-3xl mx-auto p-6 bg-white rounded-2xl shadow-md w-full">
      <h1 className="text-2xl font-semibold">Homoglyph Detector</h1>
      <p className="text-sm text-gray-600 mt-1">Upload a text file or paste text — finds likely confusable characters and suggests ASCII-friendly replacements.</p>

      <div className="mt-4 flex gap-2 items-center">
        <input type="file" accept=".txt" onChange={(e) => handleFile(e.target.files && e.target.files[0])} />
        <button className="ml-auto text-sm text-blue-600" onClick={() => { setText(""); setFound([]); setNormalized(""); }}>Clear</button>
      </div>

      <textarea className="w-full mt-4 p-3 border rounded font-mono h-40" value={text} onChange={(e) => { setText(e.target.value); analyze(e.target.value); }} placeholder="Paste or edit text here..." />

      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h2 className="font-medium">Detections ({found.length})</h2>
          <div className="mt-2 p-3 border rounded bg-gray-50 text-sm font-mono min-h-[80px]">
            {found.length === 0 ? (
              <div className="text-gray-500">No suspicious characters</div>
            ) : (
              <table className="w-full text-left text-sm">
                <thead>
                  <tr><th>Index</th><th>Char</th><th>Replace</th><th>Context</th></tr>
                </thead>
                <tbody>
                  {found.map((h, idx) => (
                    <tr key={idx} className="border-t"><td className="py-1">{h.index}</td><td className="py-1 font-mono">{h.char}</td><td className="py-1 font-mono">{h.base}</td><td className="py-1 font-mono">{text.slice(Math.max(0,h.index-6), h.index+6)}</td></tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <div>
          <h2 className="font-medium">Normalized output</h2>
          <div className="mt-2 p-3 border rounded bg-gray-50 min-h-[80px] font-mono whitespace-pre-wrap">{normalized || <span className="text-gray-500">—</span>}</div>
          <div className="mt-3 flex gap-2">
            <button className="px-3 py-2 bg-blue-600 text-white rounded" onClick={() => { const blob = new Blob([normalized], { type: "text/plain" }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "sanitized.txt"; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); }}>Download sanitized.txt</button>
            <button className="px-3 py-2 bg-gray-100 rounded" onClick={() => navigator.clipboard?.writeText(normalized || "")}>Copy</button>
          </div>
        </div>
      </div>

      <p className="mt-4 text-xs text-gray-500">Tip: Expand `HOMOGLYPH_MAP` with Unicode confusables for stronger detection. This project is intentionally lightweight for internship evaluation.</p>
    </div>
  );
}