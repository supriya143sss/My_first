import React from "react";
import HomoglyphDetector from "./components/HomoglyphDetector";

export default function App() {
  return (
    <div className="min-h-screen flex items-start justify-center py-10">
      <HomoglyphDetector />
    </div>
  );
}