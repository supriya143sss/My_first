# homoglyph-detector

A lightweight React app that detects likely homoglyph (confusable) Unicode characters in text and suggests ASCII-friendly replacements.

## Quick start

1. Install dependencies:

```bash
npm install
```

2. Start the dev server:

```bash
npm start
```

3. Open `http://localhost:3000` in your browser. Upload `sample_files/suspicious-sample.txt` or paste text.

## Notes
- The project uses a compact confusables mapping in `src/components/HomoglyphDetector.jsx` — expand it using the Unicode Consortium confusables file for production use.
- This repository is prepared for internship evaluation: simple, readable, and runnable.
