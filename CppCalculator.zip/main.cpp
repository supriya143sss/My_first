#include <iostream>
#include "calculator.h"

using namespace std;

int main() {
    Calculator calc;
    int choice;
    double a, b;

    do {
        cout << "\n--- C++ Calculator ---\n";
        cout << "1. Add\n";
        cout << "2. Subtract\n";
        cout << "3. Multiply\n";
        cout << "4. Divide\n";
        cout << "5. Power\n";
        cout << "6. Square Root\n";
        cout << "0. Exit\n";
        cout << "Choose an option: ";
        cin >> choice;

        try {
            switch (choice) {
                case 1:
                    cout << "Enter two numbers: ";
                    cin >> a >> b;
                    cout << "Result: " << calc.add(a, b) << endl;
                    break;
                case 2:
                    cout << "Enter two numbers: ";
                    cin >> a >> b;
                    cout << "Result: " << calc.subtract(a, b) << endl;
                    break;
                case 3:
                    cout << "Enter two numbers: ";
                    cin >> a >> b;
                    cout << "Result: " << calc.multiply(a, b) << endl;
                    break;
                case 4:
                    cout << "Enter two numbers: ";
                    cin >> a >> b;
                    cout << "Result: " << calc.divide(a, b) << endl;
                    break;
                case 5:
                    cout << "Enter base and exponent: ";
                    cin >> a >> b;
                    cout << "Result: " << calc.power(a, b) << endl;
                    break;
                case 6:
                    cout << "Enter number: ";
                    cin >> a;
                    cout << "Result: " << calc.squareRoot(a) << endl;
                    break;
                case 0:
                    cout << "Exiting calculator.\n";
                    break;
                default:
                    cout << "Invalid choice!\n";
            }
        } catch (const std::exception &e) {
            cout << "Error: " << e.what() << endl;
        }
    } while (choice != 0);

    return 0;
}
